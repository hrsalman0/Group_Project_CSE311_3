<?php
$db = mysqli_connect("localhost","root","","com_database_project");
?>